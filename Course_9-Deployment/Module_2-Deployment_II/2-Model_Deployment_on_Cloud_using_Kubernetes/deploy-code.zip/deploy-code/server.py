# import Flask class from the flask module
from flask import Flask, request, jsonify, render_template

import numpy as np
import pickle

# Create Flask object to run
app = Flask(__name__, template_folder='templates')

# Home page
@app.route('/')
def home():
    return render_template('index.html')

    #return "Hi, Welcome to my app to show how to deploy a ML model with flask and docker"

# Prediction page
@app.route('/predicts', methods=['POST'])
def predicts():
    data = request.get_json(force=True)
    predict_data = np.array([data['sl'], data['sw'], data['pl'], data['pw']]).reshape((-1,4))
    y_hat = svm_model.predict(predict_data).reshape((1, -1))
    output = y_hat.astype(int)
    output = output.tolist()
    return(jsonify(results=output))

@app.route('/predict', methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''
    sepal_length = float(request.form.get('sepal_length'))
    sepal_width = float(request.form.get('sepal_width'))
    petal_length = float(request.form.get('petal_length'))
    petal_width = float(request.form.get('petal_width'))
    predict_data = np.array([sepal_length, sepal_width, petal_length, petal_width]).reshape((-1,4))
    y_hat = svm_model.predict(predict_data).reshape((1, -1))
    output = y_hat.astype(int)
    output = output.tolist()
    print("Output :", output)
    return render_template('index.html', prediction_text='The Flower is {}'.format(output))

    #return (jsonify(results=output))
    '''
    prediction = model.predict(
        [[sepal_length, sepal_width, petal_length, petal_width]])



    if prediction == [0]:

        return render_template('index.html', prediction_text='The Flower is {}'.format('Iris Setosa'))

    if prediction == [1]:
        return render_template('index.html', prediction_text='The Flower is {}'.format('Iris Versicolour'))

    if prediction == [2]:
        return render_template('index.html', prediction_text='The Flower is {}'.format('Iris Virginica'))
    '''

# Load the pre-trained and persisted SVM model
# Note: The model will be loaded only once at the start of the server
def load_model():
	global svm_model

	with open('models/svm.pckl', 'rb') as svm_file:
	       svm_model = pickle.load(svm_file)

if __name__ == "__main__":
    print("**Starting Server...")
    # Call function that loads Model
    load_model()
    print("**Model loaded...")
    # Run Server
    app.run(host="0.0.0.0", port=5000)
