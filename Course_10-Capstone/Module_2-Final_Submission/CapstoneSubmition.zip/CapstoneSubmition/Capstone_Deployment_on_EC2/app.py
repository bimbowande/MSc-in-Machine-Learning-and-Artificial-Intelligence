from flask import Flask, request, jsonify, render_template
import pandas as pd
import pickle
import numpy as np



app = Flask(__name__)


model_gender = pickle.load(open('model_gender.pkl','rb'))
model_age = pickle.load(open('model_age.pkl','rb'))


df_test_gender_x = pd.read_csv("dfead_test_gender_pred_x_with_device_id.csv")
df_test_age_x = pd.read_csv("dfead_test_age_pred_x_with_device_id.csv")

df_test_gender_sample = df_test_gender_x.sample(50)
df_test_gender_sample.drop("Unnamed: 0",axis=1,inplace=True)

df_test_age_sample = df_test_age_x.sample(50)
df_test_age_sample.drop("Unnamed: 0",axis=1,inplace=True)

gender_prediction = model_gender.predict(df_test_gender_sample.drop("device_id", axis=1))
age_prediction = model_age.predict(df_test_age_sample.drop("device_id", axis=1)) 
age_prediction = age_prediction.astype(int)

gender_prediction_df = ["Male" if (i==1) else "Female" for i in gender_prediction]
df_campaign1 = ["Applicable" if(i==0) else "Not Applicable" for i in gender_prediction]
df_campaign2 = ["Applicable" if(i==0) else "Not Applicable" for i in gender_prediction]
df_campaign3 = ["Applicable" if(i==1) else "Not Applicable" for i in gender_prediction]
df_campaign4 = ["Applicable" if(i>=0 and i<=24) else "Not Applicable" for i in age_prediction]
df_campaign5 = ["Applicable" if(i>=24 and i<=32) else "Not Applicable" for i in age_prediction]
df_campaign6 = ["Applicable" if(i>=32) else "Not Applicable" for i in age_prediction]


@app.route('/')
def index(): 
    list0 = df_test_gender_sample.device_id
    list1 = gender_prediction_df
    list2 = age_prediction
    list3 = df_campaign1
    list4 = df_campaign2
    list5 = df_campaign3
    list6 = df_campaign4
    list7 = df_campaign5
    list8 = df_campaign6
    zipped_lists = zip(list0, list1, list2, list3, list4, list5, list6, list7, list8)
    return render_template('index.html', zipped_lists=zipped_lists)

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
